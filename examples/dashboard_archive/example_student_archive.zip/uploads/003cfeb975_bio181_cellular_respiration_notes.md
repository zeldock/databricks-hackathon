# BIO 181 — Lecture 7: Cellular Respiration

Glycolysis occurs in the cytoplasm and converts one glucose molecule into two pyruvate, netting 2 ATP and 2 NADH.
Pyruvate oxidation takes place in the mitochondrial matrix, producing acetyl-CoA and releasing carbon dioxide.
The Krebs cycle (citric acid cycle) completes the oxidation of glucose and generates NADH, FADH2 and ATP.
Oxidative phosphorylation uses the electron transport chain on the inner mitochondrial membrane.
The electron transport chain pumps protons, and the resulting proton gradient drives ATP synthase.
Oxygen is the final electron acceptor and combines with electrons and protons to form water.
Aerobic respiration yields roughly 30 to 32 ATP per glucose molecule.
Without oxygen, cells rely on fermentation to regenerate NAD+ so that glycolysis can continue.
Lactic acid fermentation occurs in muscle cells, while alcohol fermentation occurs in yeast.
