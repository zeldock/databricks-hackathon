# CH 101 — Stoichiometry Review

A mole contains Avogadro's number of particles, about 6.022 x 10^23.
Molar mass converts between grams and moles and is found by summing atomic masses from the periodic table.
Balanced chemical equations give the mole ratios used in stoichiometry calculations.
The limiting reactant is the reactant that is completely consumed first and determines the theoretical yield.
Percent yield equals the actual yield divided by the theoretical yield, multiplied by one hundred.
Molarity is moles of solute per liter of solution and is used for solution stoichiometry.
Empirical formulas show the simplest whole-number ratio of atoms in a compound.
